﻿using System.Windows.Forms;

namespace LabManager
{
    public partial class RobotInformationForm : Form
    {
        public RobotInformationForm()
        {
            InitializeComponent();
        }
    }
}
